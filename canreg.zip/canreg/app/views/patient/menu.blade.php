<ul class="nav nav-pills nav-stacked">
    <!--<li class="active">{{ link_to('patient/add/basic','Registration') }} </li>-->
    <li>{{ link_to('patient/add/basic','Registration') }}</li>
    <li><a href="#" id="registerpat">Registration</a></li>
</ul>
