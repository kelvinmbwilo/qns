<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', function()
{
	return View::make('master');
});

///////////////////////////////////////////////////////////////////////////////
///////////////////Staff Management///////////////////////////
////////////////////////////////////////////////////////////////////////////////

Route::get('staff/add',array('as'=>'addstaff', function()
{
	return View::make('staff.add');
}));

Route::get('staff/manage',array('as'=>'managestaff', function()
{
               $staff = Staff::all();
	return View::make('staff.manage',compact('staff'));
}));

Route::get('staff/edit/{id}',array('as'=>'editstaff', function($id)
{
               $staff = Staff::find($id);
	return View::make('staff.edit',compact('staff'));
}));



Route::get('staff/editcourse/{id}',array('as'=>'editstaffcourse', function($id)
{
               $cu = CourseStaff::find($id);
               $staff = Staff::find($cu->staff_id);
	return View::make('staff.editcourse',compact('cu','staff'));
}));


Route::get('staff/assign/{id}',array('as'=>'assignstaff', function($id)
{
               $staff = Staff::find($id);
	return View::make('staff.assign',compact('staff'));
}));

Route::get('staff/course/{id}',array('as'=>'sfaffcourse', function($id)
{
               $staff = Staff::find($id);
               $course = CourseStaff::where('staff_id',$id)->orderBy('created_at','desc')->get();
	return View::make('staff.courses',compact('staff','course'));
}));

Route::post('staff/add', array('as'=>'addstaff1','uses'=>'StaffController@store'));

Route::post('staff/editcourse', array('as'=>'editdtaffcourse1','uses'=>'StaffController@updatecourse'));

Route::post('staff/delete/{id}', array('as'=>'deletestaff','uses'=>'StaffController@destroy'));



Route::post('staff/editc', array('as'=>'editstaff1','uses'=>'StaffController@update'));

Route::post('staff/assign', array('as'=>'assignstaff','uses'=>'StaffController@assign'));
///////////////////////////////////////////////////////////////////////////////
///////////////////Course Management///////////////////////////


Route::get('course/add',array('as'=>'addcourse', function()
{
	return View::make('course.add');
}));

Route::get('course/manage',array('as'=>'managecourse', function()
{
               $course = Course::all();
	return View::make('course.manage',compact('course'));
}));

Route::get('course/edit/{id}',array('as'=>'editcourse', function($id)
{
               $course = Course::find($id);
	return View::make('course.edit',compact('course'));
}));



Route::post('course/add', array('as'=>'addcourse1','uses'=>'CourseController@store'));

Route::post('course/delete/{id}', array('as'=>'deletecourse','uses'=>'CourseController@destroy'));

Route::post('course/edit', array('as'=>'editcourse1','uses'=>'CourseController@update'));

Route::post('staff/deletecourse/{id}', array('as'=>'deletestaffcourse','uses'=>'StaffController@destroycourse'));




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////staff Summary/ ////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Route::get('staff/summary/{id}',array('as'=>'editstaff', function($id)
{
               $staff = Staff::find($id);
               
	return View::make('staff.sumary',compact('staff','cu'));
}));
