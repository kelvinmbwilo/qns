<?php

class StaffController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		return "imefika";
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		//
	}
        
                public function assign()
	{
            CourseStaff::create(array(
                "course_id"=>Input::get('course'),
                "staff_id"  =>Input::get('id'),
                "sitting"   =>Input::get('time'),
                "cost"    => Course::find(Input::get('course'))->cost,
                "mode"  => Input::get('mode')
             ));
            
            return Redirect::route('managestaff');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
	   $staff = Staff::create(array(
                "fname"=>Input::get('firstname'),
                "mname"=>Input::get('middlename'),
                "lastname"=>Input::get('lastname'),
                "staffid"=>Input::get('staffid'),
                "status"=>"active"
                ));
               
                return Redirect::route('managestaff');
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update()
	{
                    $staff = Staff::find(Input::get('id'));
                    $staff->staffid = Input::get('staffid');
                    $staff->fname = Input::get('firstname');
                    $staff->mname = Input::get('middlename');
                    $staff->lastname = Input::get('lastname');
                    $staff->status = Input::get('status');
                    $staff->save();
                    
                    return Redirect::route('managestaff');
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
                    $staff = Staff::find($id);
                    $course = CourseStaff::where('staff_id',$id)->get();
                    foreach ($course as $value)
                    {
                        $value->delete();
                    }
                    
                    $staff->delete();
	}
         
            
        public function destroycourse($id)
	{
                    $staff = CourseStaff::find($id);
                    $staff->delete();
	}
        
        public function updatecourse()
	{
                    $staff = CourseStaff::find(Input::get('id'));
                    $staff->status = Input::get('status');
                    $staff->mode  = Input::get('mode');
                    $staff->result  =Input::get('result');
                    $staff->save();
                    $cou = Staff::find($staff->staff_id);
                            return Redirect::to("staff/course/{$cou->id}");

	}
        

}