@extends('master')

@section('content')
<h3 class="text-center">Edit Staff</h3>
<div class='col-sm-8 col-sm-offset-2'>
    {{ Form::open(array("url"=>route('editstaff1'),"class"=>"form-horizontal")) }}
    <input type="hidden" name='id' value="{{ $staff->id }}" />
    <div class='form-group'>
        {{ Form::label('staffid', 'Staff ID/Reg_no',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('staffid',$staff->staffid,array('class'=>'form-control','placeholder'=>'Staff ID','required'=>'required')) }} </div>
    </div>
<div class='form-group'>
        {{ Form::label('firstname', 'First Name',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('firstname',$staff->fname,array('class'=>'form-control','placeholder'=>'First Name','required'=>'required')) }} </div>
    </div>
    
    <div class='form-group'>
        {{ Form::label('middlename', 'Middle Name',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('middlename',$staff->mname,array('class'=>'form-control','placeholder'=>'Middle Name')) }} </div>
    </div>
    
<div class='form-group'>
        {{ Form::label('lastname', 'Last Name',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('lastname',$staff->lastname,array('class'=>'form-control','placeholder'=>'Last Name','required'=>'required')) }} </div>
    </div>
<div class='form-group'>
        {{ Form::label('status', 'Status',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::select('status',array("active"=>"Active",'deactive'=>"Deactive"),$staff->status,array('class'=>'form-control','required'=>'requiered')) }}  </div>
    </div>
    
      
   <div class='col-sm-12 form-group text-center'>
        {{ Form::submit('Submit',array('class'=>'btn btn-primary','id'=>'submitqn')) }}
        
    </div>
  {{ Form::close() }}
</div>
      
@stop


