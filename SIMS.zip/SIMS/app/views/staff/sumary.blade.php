@extends('master')

@section('content')
    <div class='row'>
        <div class='col-sm-3'>
           <ul class="nav nav-pills nav-stacked">
               <li class="active"><a href="{{ url("staff/course/{$staff->id}") }}">Courses <i class="fa fa-chevron-right pull-right"></i></a></li>
                <li><a href="{{ url("staff/summary/{$staff->id}") }}">Summary <i class="fa fa-chevron-right pull-right"></i></a></li>
            </ul>
        </div>
        
        <div class='col-sm-9'>
            <h3 class="text-center">Course Summary For <span style='text-transform: capitalize'>{{ $staff->fname }} {{$staff->mname  }} {{ $staff->lastname  }}</span></h3>
            <table class="table table-hover">
                <tr>
                    <td>
                        Total Examination Registered
                    </td>
                    <td>
                       {{ DB::table('staffcourse')->where('staff_id', '=', $staff->id)->count() }}
                    </td>
                </tr>
                
                <tr>
                    <td>
                        Total Examination Done
                    </td>
                    <td>
                       {{ DB::table('staffcourse')->where('staff_id', '=', $staff->id)->where("status","registered")->count() }}
                    </td>
                </tr>
                
                <tr>
                    <td>
                        Total Examination Passed
                    </td>
                    <td>
                       {{ DB::table('staffcourse')->where('staff_id', '=', $staff->id)->where("result","pass")->count() }}
                    </td>
                </tr>
                
                <tr>
                    <td>
                        Total Examination Failed
                    </td>
                    <td>
                       {{ DB::table('staffcourse')->where('staff_id', '=', $staff->id)->where("result","fail")->count() }}
                    </td>
                </tr>
                
                <tr>
                    <td>
                         Total Examination Repeated
                    </td>
                    <td>
                       {{ DB::table('staffcourse')->where('staff_id', '=', $staff->id)->where("mode","repeate")->count() }}
                    </td>
                </tr>
            </table>
            
            <h3>Costing</h3>
             <table class="table table-hover">
                <tr>
                    <td>
                        Total Cost For All Registered Examination
                    </td>
                    <td>
                       {{ DB::table('staffcourse')->where('staff_id', '=', $staff->id)->sum('cost') }}
                    </td>
                </tr>
                
                <tr>
                    <td>
                        Total Cost For Examination Passed
                    </td>
                    <td>
                       {{ DB::table('staffcourse')->where('staff_id', '=', $staff->id)->where("result","pass")->sum('cost') }}
                    </td>
                </tr>
                
                <tr>
                    <td>
                        Total Cost For Examination Failed
                    </td>
                    <td>
                       {{ DB::table('staffcourse')->where('staff_id', '=', $staff->id)->where("result","fail")->sum('cost') }}
                    </td>
                </tr>
                
                <tr>
                    <td>
                         Total Cost For Examination Repeated
                    </td>
                    <td>
                       {{ DB::table('staffcourse')->where('staff_id', '=', $staff->id)->where("mode","repeate")->sum('cost') }}
                    </td>
                </tr>
            </table>
            
        </div>
    </div>
      
@stop