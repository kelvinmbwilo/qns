@extends('master')

@section('content')
    <div class='row'>
        <div class='col-sm-3'>
           <ul class="nav nav-pills nav-stacked">
               <li class="active"><a href="{{ url("staff/course/{$staff->id}") }}">Courses <i class="fa fa-chevron-right pull-right"></i></a></li>
                <li><a href="{{ url("staff/summary/{$staff->id}") }}">Summary <i class="fa fa-chevron-right pull-right"></i></a></li>
            </ul>
        </div>
        
        <div class='col-sm-9'>
            <h3 class="text-center">Edit Course For <span style='text-transform: capitalize'>{{ $staff->fname }} {{$staff->mname  }} {{ $staff->lastname  }}</span></h3>
            <h4 class="text-center">Course: {{$cu->course->tittle }}- {{$cu->course->discr }}({{$cu->course->code  }})</h4>
                <div class='col-sm-8 col-sm-offset-2'>
                    {{ Form::open(array("url"=>route('editdtaffcourse1'),"class"=>"form-horizontal")) }}
                    <input type="hidden" value="{{ $cu->id }}" name='id' />
                <div class='form-group'>
                        {{ Form::label('status', 'Course Status',array('class'=>'control-label col-sm-4')) }}
                         <div class='col-sm-8'>{{ Form::select('status',array("registered"=>"Registered",'done'=>"Done",'canceled'=>"Canceled"),$cu->status,array('class'=>'form-control','required'=>'requiered')) }}  </div>
                    </div>

                    <div class='form-group'>
                        {{ Form::label('mode', 'Sitting',array('class'=>'control-label col-sm-4')) }}
                        <div class='col-sm-8'>{{ Form::select('mode',array("first"=>"First Registration",'repeate'=>"Repeating"),$cu->mode,array('class'=>'form-control','required'=>'requiered')) }}  </div>
                    </div>

                    <div class='form-group'>
                        {{ Form::label('result', 'Result',array('class'=>'control-label col-sm-4')) }}
                        <div class='col-sm-8'>{{ Form::select('result',array("pass"=>"Pass",'fail'=>"Fail",'Not Filled'=>'Not Filled'),$cu->result,array('class'=>'form-control','required'=>'requiered')) }}  </div>
                    </div>

                   <div class='col-sm-12 form-group text-center'>
                        {{ Form::submit('Save Changes',array('class'=>'btn btn-primary')) }}

                    </div>
                  {{ Form::close() }}
                </div>
        </div>
    </div>
      
@stop