@extends('master')

@section('content')
<div class='col-sm-8 col-sm-offset-2'>
    {{ Form::open(array("url"=>route('addstaff1'),"class"=>"form-horizontal")) }}

    <div class='form-group'>
        {{ Form::label('staffid', 'Staff ID/Reg_no',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('staffid','',array('class'=>'form-control','placeholder'=>'Staff ID','required'=>'required')) }} </div>
    </div>
<div class='form-group'>
        {{ Form::label('firstname', 'First Name',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('firstname','',array('class'=>'form-control','placeholder'=>'First Name','required'=>'required')) }} </div>
    </div>
    
    <div class='form-group'>
        {{ Form::label('middlename', 'Middle Name',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('middlename','',array('class'=>'form-control','placeholder'=>'Middle Name')) }} </div>
    </div>
    
<div class='form-group'>
        {{ Form::label('lastname', 'Last Name',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('lastname','',array('class'=>'form-control','placeholder'=>'Last Name','required'=>'required')) }} </div>
    </div>

      
   <div class='col-sm-12 form-group text-center'>
        {{ Form::submit('Submit',array('class'=>'btn btn-primary','id'=>'submitqn')) }}
        
    </div>
  {{ Form::close() }}
</div>
      
@stop
