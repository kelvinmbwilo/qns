@extends('master')

@section('content')
    <h3>Manage Course</h3>
<table class="table" id="stafftable">
    <thead>
    <tr>
        <th>#</th>
        <th>
            Staff ID
        </th>
        <th>
            Name
        </th>
        <th>
            Action
        </th>
        
    </tr>
    </thead>
   <?php $count=1 ?>
    @foreach($staff as $us)
    <tr>
        <td>{{ $count++ }}</td>
        <td>{{ $us->staffid }} </td>
        <td style='text-transform: capitalize'>
            {{ $us->fname }} {{$us->mname  }} {{ $us->lastname  }}</td>
        <td id='{{ $us->id }}'>
            @if($us->status == 'deactive')
            <span class='badge'>Deactive</span>
            @else
            <a href="{{ url("staff/assign/{$us->id}") }}" title="assign course" class="edituser"><i class="fa fa-plus text-warning"></i> assign</a>&nbsp;&nbsp;&nbsp;
            
            @endif
            <a href="{{ url("staff/course/{$us->id}") }}" title="View Staff Summary" class="edituser"><i class="fa fa-list text-success"></i> info</a>&nbsp;&nbsp;&nbsp;
            <a href="{{ url("staff/edit/{$us->id}") }}" title="edit Staff" class="edituser"><i class="fa fa-pencil text-info"></i> edit</a>&nbsp;&nbsp;&nbsp;
            <a href="#b" title="delete Staff" class="deletestaff"><i class="fa fa-trash-o text-danger"></i> delete</a>
        </td>
        
       
    @endforeach
    
 
</table>
      
@stop
