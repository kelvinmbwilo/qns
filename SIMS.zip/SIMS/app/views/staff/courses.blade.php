@extends('master')

@section('content')

    <div class='row'>
        <div class='col-sm-3'>
           <ul class="nav nav-pills nav-stacked">
               <li class="active"><a href="{{ url("staff/course/{$staff->id}") }}">Courses <i class="fa fa-chevron-right pull-right"></i></a></li>
                <li><a href="{{ url("staff/summary/{$staff->id}") }}">Summary <i class="fa fa-chevron-right pull-right"></i></a></li>
            </ul>
        </div>
        
        <div class='col-sm-9'>
            <h3 style='text-transform: capitalize'>Courses For {{ $staff->fname }} {{$staff->mname  }} {{ $staff->lastname  }} </h3>
            <table class="table table-hover" id="coursetable">
                <thead>
            <tr>
                <th>#</th>
                <th>
                    Course
                </th>
                <th>
                    Sitting
                </th>
                <th>
                    Status
                </th>
                <th>
                    Result
                </th>
                <th>
                    Action
                </th>
            </tr>
            </thead>
           <?php $count=1 ?>
            @foreach($course as $cu )
            <tr>
                <td>{{ $count++ }}</td>
                <td>{{$cu->course->tittle }} - {{$cu->course->discr }}({{$cu->course->code  }}) </td>
                <td>{{$cu->sitting }} {{ date("Y",strtotime($cu->created_at)) }}</td>
                <td>{{$cu->status }}</td>
                <td>
                    @if($cu->result == "" )
                    Not Filled
                    @else
                    {{$cu->result }}
                    @endif
                    {{$cu->result }}
                </td>
                <td id='{{ $cu->id }}'>
                    @if($staff->status == "deactive" )
                    @else
                    <a href="{{ url("staff/editcourse/{$cu->id}") }}" title="edit Staff" class="edituser"><i class="fa fa-pencil text-info"></i> edit</a>&nbsp;&nbsp;&nbsp;
                    
                    @endif
                    <a href="#b" title="delete this course" class="deletestaffcourse"><i class="fa fa-trash-o text-danger"></i> delete</a>
                </td>


            @endforeach


        </table>
            
        </div>
    </div>
      
@stop
