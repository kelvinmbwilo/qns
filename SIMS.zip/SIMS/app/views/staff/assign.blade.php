@extends('master')

@section('content')
<h3 class="text-center">Assign Course to <span style='text-transform: capitalize'>{{ $staff->fname }} {{$staff->mname  }} {{ $staff->lastname  }}</span></h3>
<div class='col-sm-8 col-sm-offset-2'>
    {{ Form::open(array("url"=>route('assignstaff'),"class"=>"form-horizontal")) }}
    <input type="hidden" value="{{ $staff->id }}" name='id' />
<div class='form-group'>
        {{ Form::label('course', 'Course',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::select('course',Course::lists('code','id'),'',array('class'=>'form-control','required'=>'requiered')) }}  </div>
    </div>
    
    <div class='form-group'>
        {{ Form::label('time', 'Sitting',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::select('time',array("june"=>"June Sitting",'december'=>"December Sitting"),'',array('class'=>'form-control','required'=>'requiered')) }}  </div>
    </div>
    
    <div class='form-group'>
        {{ Form::label('mode', 'Registration Mode',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::select('mode',array("first"=>"First Registration",'repeate'=>"Repeating"),'',array('class'=>'form-control','required'=>'requiered')) }}  </div>
    </div>

   <div class='col-sm-12 form-group text-center'>
        {{ Form::submit('Assign',array('class'=>'btn btn-primary')) }}
        
    </div>
  {{ Form::close() }}
</div>
      
@stop