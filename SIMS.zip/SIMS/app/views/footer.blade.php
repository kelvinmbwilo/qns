@section('footer')
<footer class="container text-center" >
    &copy;{{ date("Y") }} Road Safety Project
</footer>
@show
