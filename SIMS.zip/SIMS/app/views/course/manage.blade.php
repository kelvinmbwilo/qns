@extends('master')

@section('content')
    <h3>Manage Course</h3>
<table class="table">
    <tr>
        <th>#</th>
        <th>
            Tittle
        </th>
        <th>
            Code
        </th>
        <th>
            Discription
        </th>
        <th>
            Cost ($)
        </th>
        <th>
            Action
        </th>
        
    </tr>
   <?php $count=1 ?>
    @foreach($course as $us)
    <tr>
        <td>{{ $count++ }}</td>
        <td>{{ $us->tittle }} </td>
        <td>{{ $us->code }}</td>
        <td>{{ $us->discr }}</td>
        <td>{{ $us->cost }}</td>
        <td id='{{ $us->id }}'>
            <a href="{{ url("course/edit/{$us->id}") }}" title="edit course" class="edituser"><i class="fa fa-pencil text-info"></i> edit</a>&nbsp;&nbsp;&nbsp;
            <a href="#b" title="delete course" class="deletepost"><i class="fa fa-trash-o text-danger"></i> delete</a>
        </td>
        
       
    @endforeach
    
 
</table>
      
@stop
