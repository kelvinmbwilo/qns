@extends('master')

@section('content')
<div class='col-sm-8 col-sm-offset-2'>
    {{ Form::open(array("url"=>route('addcourse1'),"class"=>"form-horizontal")) }}

    <div class='form-group'>
        {{ Form::label('tittle', 'Tittle',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('tittle','',array('class'=>'form-control','placeholder'=>'Tittle (CPA)','required'=>'required')) }} </div>
    </div>
<div class='form-group'>
        {{ Form::label('discr', 'Discription',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('discr','',array('class'=>'form-control','placeholder'=>'Discription (Introduction to accounts)','required'=>'required')) }} </div>
    </div>
    
    <div class='form-group'>
        {{ Form::label('code', 'Course Code',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('code','',array('class'=>'form-control','placeholder'=>'Course Code( F4)','required'=>'required')) }} </div>
    </div>
    
<div class='form-group'>
        {{ Form::label('cost', 'Cost',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('cost','',array('class'=>'form-control','placeholder'=>'Course Cost','required'=>'required')) }} </div>
    </div>

      
   <div class='col-sm-12 form-group text-center'>
        {{ Form::submit('Submit',array('class'=>'btn btn-primary','id'=>'submitqn')) }}
        
    </div>
  {{ Form::close() }}
</div>
      
@stop
