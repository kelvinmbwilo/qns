@extends('master')

@section('content')
<h3 class="text-center">Edit Course</h3>
<div class='col-sm-8 col-sm-offset-2'>
    {{ Form::open(array("url"=>route('editcourse1'),"class"=>"form-horizontal")) }}
    <input type="hidden" value="{{ $course->id }}" name='id'>
    <div class='form-group'>
        {{ Form::label('tittle', 'Tittle',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('tittle',$course->tittle,array('class'=>'form-control','placeholder'=>'Tittle (CPA)','required'=>'required')) }} </div>
    </div>
<div class='form-group'>
        {{ Form::label('discr', 'Discription',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('discr',$course->discr,array('class'=>'form-control','placeholder'=>'Discription (Introduction to accounts)','required'=>'required')) }} </div>
    </div>
    
    <div class='form-group'>
        {{ Form::label('code', 'Course Code',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('code',$course->code,array('class'=>'form-control','placeholder'=>'Course Code( F4)','required'=>'required')) }} </div>
    </div>
    
<div class='form-group'>
        {{ Form::label('cost', 'Cost',array('class'=>'control-label col-sm-4')) }}
        <div class='col-sm-8'>{{ Form::text('cost',$course->cost,array('class'=>'form-control','placeholder'=>'Course Cost','required'=>'required')) }} </div>
    </div>

      
   <div class='col-sm-12 form-group text-center'>
        {{ Form::submit('Save Changes',array('class'=>'btn btn-primary','id'=>'submitqn')) }}
        
    </div>
  {{ Form::close() }}
</div>
      
@stop
