<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>SIMS</title>
        <style>@import url(//fonts.googleapis.com/css?family=Lato:700);</style>
        {{ HTML::style("bootstrap/css/bootstrap.css") }}
        {{ HTML::style("bootstrap/css/bootstrap-theme.css") }}
        {{ HTML::style("font-awesome/css/font-awesome.css") }}
        {{ HTML::style("jqueryui/css/start/jquery-ui.css") }}
        {{ HTML::style("DataTables/media/css/jquery.dataTables.css") }}
        {{ HTML::style("DataTables/media/css/jquery.dataTables_themeroller.css") }}
        {{ HTML::script("js/jquery-1.9.1.js") }}
        
    </head>
    <body style="padding-top: 100px">
        @include('header')
        <div class="container">
            <div class='row'>
                <h2 class="text-center">@yield('heading') </h2>
                <div  id="maincontents">
                   @yield('content') 
                   
                </div>
                    </div>
                
                </div>
        @include('footer')
        {{ HTML::script("jqueryui/js/jquery-ui-1.10.3.custom.js") }}
        {{ HTML::script("bootstrap/js/bootstrap.js") }}
        {{ HTML::script("DataTables/media/js/jquery.dataTables.js") }}
        {{ HTML::script("js/script1.js") }}
    </body>
</html>
