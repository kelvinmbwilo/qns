<?php
class Service extends Eloquent  {
	protected $table = 'services';
	
	
}