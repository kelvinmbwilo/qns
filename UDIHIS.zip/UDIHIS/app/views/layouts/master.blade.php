@include('layouts.incs.header')

@yield('content')

@include('layouts.incs.footer')