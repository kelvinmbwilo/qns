@extends('dashboard')
@section('main')
<h1 class="page-title">
                        <i class="icon-user-md"></i>
                        Insurance management                  
</h1>

                    <div class="action-nav-normal">
                        <div class="row">



                        </div> <!-- /stat-container -->
<div class="widget-header">
    
</div>
@stop

