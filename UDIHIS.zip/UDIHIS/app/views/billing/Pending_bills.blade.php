@extends('dashboard')
@section('main')
<h1 class="page-title">
                        <i class="icon-exchange"></i>
                        Pending Bills					
                    </h1>

                    <div class="action-nav-normal">
                        <div class="row">



                        </div> <!-- /stat-container -->

                        <div class="widget-header">
                            <i class="icon-th-list"></i>
                            <h3>Billing List</h3>
                        </div> <!-- /widget-header -->

                        <div class="widget-content">

                            <table class="table  table-bordered">
                                    <tr>
                                        <th>#</th>
                                        <th>date</th>
                                        <th>Patient Name </th>
                                        <th>Bill Type</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                          <th>options</th>  
                               
                                    </tr>
                                <tbody id="provide_medication">
                                   
                                    <tr>
                                       



                                        
                                        
                                    </tr>
                                    
                                  

                                </tbody>
                            </table>

                        </div> <!-- /widget-content -->

@stop
