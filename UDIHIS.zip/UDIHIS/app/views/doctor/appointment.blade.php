@extends('dashboard')
@section('main')
				
				<h1 class="page-title">
					<i class="icon-th-large"></i>
					Appointments					
				</h1>
				
				
				<div class="row">
					
					<div class="span9">
				
						
							<div class="widget-header">
								<h3>My appointments</h3>
							</div> <!-- /widget-header -->
									
							<div class="widget-content">
								
										
										
									</div>	
							</div>
						</div>
					
				
		

@stop