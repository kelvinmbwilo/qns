@extends('dashboard')
@section('main')
<h1 class="page-title">
			<i class="icon-home"></i>
			Dashboard					
		</h1>
	
		
		
								
			<div class="widget-header">
				<i class="icon-signal"></i>
				<h3>Weekly patients traffic</h3>
			</div> <!-- /widget-header -->
												
			<div class="widget-content">					
				<div id="bar-chart" class="chart-holder"></div> <!-- /bar-chart -->				
			</div> <!-- /widget-content -->
		
@stop