       <div id="footer">

            <div class="container">		

                <div class="row">

                    <div id="attribution" class="span6">

                    </div> 

                </div> <!-- /.row -->
            </div> <!-- /container -->

        </div> <!-- /footer -->