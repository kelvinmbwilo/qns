@extends('dashboard')
@section('main')
 <h1 class="page-title">
                        <i class="icon-user-md"></i>
                        Patients                    
                    </h1>

                    <div class="action-nav-normal">
                        <div class="row">



                        </div> <!-- /stat-container -->

                        <div class="widget-header">
                    
                           
                           
    
 
</div>
                            <div class="dropdown">
                        </div> <!-- /widget-header -->

                        <div class="widget-content">

                   

                        </div> <!-- /widget-content -->



@stop