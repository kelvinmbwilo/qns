<?php

$user = new User;
Artisan::add(new initApp($user));