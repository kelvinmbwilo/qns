<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('users',function($table){
			$table->increments('id');
			$table->String('email')->nullable();
            $table->String('password')->nullable();
            $table->String('first_name')->nullable();
            $table->String('middle_name')->nullable();
            $table->String('last_name')->nullable();	
            $table->String('address')->nullable();
            $table->integer('level')->nullable();
           	$table->String('contact')->nullable();
           	$table->String('status')->default('active'); 
			$table->timestamps();

		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('users');
	}

}
