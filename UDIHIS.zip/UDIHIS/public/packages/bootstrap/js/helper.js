function toString(str){
	alert(JSON.stringify(str));
}