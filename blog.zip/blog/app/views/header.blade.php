<nav class="navbar navbar-default navbar-static-top" role="navigation" style="background-color: #ffff00/**background-image: url({{asset("pattern/pattern7.png")}})*/">
    <div class="">
  <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="#">
<!--        {{ HTML::image('img/logo.jpg','',array('class'=>'img-responsive img-rounded pull-left','style'=>'height:100px; margin-left:15px;margin-right:15px')) }}-->
        {{ HTML::image('img/shekinahLOgo2.jpg','',array('class'=>'img-responsive img-rounded','style'=>'height:100px')) }}</a>
  </div>

  <!-- Collect the nav links, forms, and other content for toggling -->
  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      

    
<ul class="nav navbar-nav pull-right" style="padding-top: 50px">
    <li style="border-right: 1px solid #000000"><a href="http://shekinahgarden.co.tz/"><i class="fa fa-home"></i> Home</a></li>
      <li style="border-right: 1px solid #000000"><a href="http://shekinahgarden.co.tz/?page_id=66"><i class="fa fa-rss"></i> About Us</a></li>
      <li style="border-right: 1px solid #000000"><a href="http://shekinahgarden.co.tz/?page_id=55"><i class="fa fa-envelope-o"></i> Contacts</a></li>
      <li><a style="padding-right: 5px" href="https://www.facebook.com/pages/Shekinah-Garden/331496433608668"><i class="fa fa-facebook-square fa-2x text-info"></i></a> </li>
      <li>  <a href="#" style="padding-right: 5px"><i class="fa fa-twitter-square fa-2x" style="color: #00C0F7"></i></a> </li>
       <li>  <a href="#" style="padding-right: 5px"><i class="fa fa-instagram  text-danger fa-2x" ></i></a></li>
</ul>
      

  </div><!-- /.navbar-collapse -->
  </div>
</nav>
