<?php
class DebateController extends BaseController {
public function debate(){
    return View::make('user.debate');
    }
}