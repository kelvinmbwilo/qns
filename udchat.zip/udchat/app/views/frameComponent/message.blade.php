<li class="dropdown">
    <a class="dropdown-toggle hidden-xs hidden-sm" data-toggle="dropdown" href="#">
        <span class="glyphicon glyphicon-envelope"></span> <strong >Messages</strong> <span class="badge">3</span>  <i class="fa fa-chevron-down"></i>
    </a>
    <a class="dropdown-toggle visible-xs visible-sm" data-toggle="dropdown" href="#">
        <span class="glyphicon glyphicon-envelope"></span> <span class="badge">3</span>  <i class="fa fa-chevron-down"></i>
    </a>
    <ul class="dropdown-menu dropdown-messages">
        <li>
            <a href="#">
                <div>
                    <strong>John Smith</strong>
                    <span class="pull-right text-muted">
                        <em>Yesterday</em>
                    </span>
                </div>
                <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
            </a>
        </li>
        <li class="divider"></li>
        <li>
            <a href="#">
                <div>
                    <strong>John Smith</strong>
                    <span class="pull-right text-muted">
                        <em>Yesterday</em>
                    </span>
                </div>
                <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
            </a>
        </li>
        <li class="divider"></li>
        <li>
            <a href="#">
                <div>
                    <strong>John Smith</strong>
                    <span class="pull-right text-muted">
                        <em>Yesterday</em>
                    </span>
                </div>
                <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque eleifend...</div>
            </a>
        </li>
        <li class="divider"></li>
        <li>
            <a class="text-center" href="#">
                <strong>Read All Messages</strong>
                <span class="glyphicon glyphicon-chevron-right pull-right"></span>
            </a>
        </li>
    </ul>
    <!-- /.dropdown-messages -->
</li><!-- /.dropdown -->
