@extends('website.layout.master')

@section('contents')

<div class="pageTitle">
    <div class="container">
        <h2>About us</h2>
    </div>
</div>

<div class="container">
    <div class="bodyInner">
        <p>Butman International is a legally registered Company in Tanzania with a certificate of Incorporation No. 48251, registration was done in February 2004.
        </p><p>
            Butman has established itself in Arusha and Dar-Es-Salaam, Arusha Office being the headquarter is well concerned with Research and Tourism activities. Butman Office located in Dar-Es-Salaam is concerned with construction activities run by the Company.
        </p>
        <p><strong> Vision</strong></p><p>

            Contribution of Ideas and technical know-how to pursue quality in Tourism, Marketing in Tourism Industry, Research in Envirormental Conservation and Construction Industry.
        </p><p><strong> Mission</strong></p><p>

            To Create and Promote Sustainable Tourism and Quality Construction.
            It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).

        </p>

    </div>
</div>


@stop