@extends('website.layout.master')

@section('contents')
<div class="pageTitle">
    <div class="container">
        <h2>Gallery</h2>
    </div>
</div>

<div class="container">
    <div class="bodyInner">
        <p>
            &nbsp;
        </p>
        <p>&nbsp;
        </p><p>&nbsp;
        </p><p>&nbsp;
        </p><p>&nbsp;
        </p><p>&nbsp;
        </p><p>&nbsp;
        </p><p>&nbsp;
        </p><p>&nbsp;
        </p><p>&nbsp;
        </p>
    </div>
</div>
@stop