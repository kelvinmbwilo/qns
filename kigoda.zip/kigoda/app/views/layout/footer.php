<div id="divFooter" class="footerArea">

    <div class="divPanel">

        <div class="row-fluid">
            <div class="span12">
                <p class="copyright">
                    Copyright © 2013 Your Company. All Rights Reserved. Thanks to <a href="http://www.oswt.co.uk/">oswt</a>
                </p>

                <p class="social_bookmarks">
                    <a href="https://www.facebook.com/kigodachamwalimunyerere"><i class="social foundicon-facebook"></i> Facebook</a>
                    <a href="https://twitter.com/"><i class="social foundicon-twitter"></i> Twitter</a>
                    <a href="#"><i class="social foundicon-pinterest"></i> Pinterest</a>
                    <a href="#"><i class="social foundicon-rss"></i> Rss</a>
                </p>
            </div>
        </div>

    </div>
</div>
</div>